<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Moderator extends Model 
{

    protected $table = 'moderators';
    public $timestamps = true;

}